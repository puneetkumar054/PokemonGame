const cvs = document.getElementById("pokemon");
const ctx = cvs.getContext("2d");
// create the unit
const box = 32;
// lirectionoad images
const ground = new Image();
ground.src = "images/ground.png";
const pokemonballImg = new Image();
pokemonballImg.src = "images/pokeball.png";
const pokemonImg = new Image();
pokemonImg.src = "images/pokemon.png";
// create the pokemon
let pokemon = [];
pokemon[0] = {
    x : 9 * box,
    y : 10 * box
};
// create the pokemonball
let pokemonball = {
    x : Math.floor(Math.random()*17+1) * box,
    y : Math.floor(Math.random()*15+3) * box
}
// create the score var
let score = 0;
//control the pokemon
let direction;

document.addEventListener("keydown",directionEvent);

function directionEvent(event){
    let key = event.keyCode;
    if( key == 37 && direction != "RIGHT"){
        direction = "LEFT";
    }else if(key == 38 && direction != "DOWN"){
        direction = "UP";
    }else if(key == 39 && direction != "LEFT"){
        direction = "RIGHT";
    }else if(key == 40 && direction != "UP"){
        direction = "DOWN";
    }
}

// cheack collision function
function collision(head,array){
    for(let i = 0; i < array.length; i++){
        if(head.x == array[i].x && head.y == array[i].y){
            return true;
        }
    }
    return false;
}

// draw everything to the canvas
function draw(){
    
    ctx.drawImage(ground,0,0);
    
    for( let i = 0; i < pokemon.length ; i++){
        ctx.drawImage(pokemonImg, pokemon[i].x, pokemon[i].y, box, box);
    }
    
    ctx.drawImage(pokemonballImg, pokemonball.x, pokemonball.y, box, box);
    
    // old head position
    let pokemonX = pokemon[0].x;
    let pokemonY = pokemon[0].y;
    
    // which direction
    if( direction == "LEFT") pokemonX -= box;
    if( direction == "UP") pokemonY -= box;
    if( direction == "RIGHT") pokemonX += box;
    if( direction == "DOWN") pokemonY += box;
    
    // if the pokemon eats the pokemonball
    if(pokemonX == pokemonball.x && pokemonY == pokemonball.y){
        score++;
        
        pokemonball = {
            x : Math.floor(Math.random()*17+1) * box,
            y : Math.floor(Math.random()*15+3) * box
        }
    }else{
        // remove the tail
        pokemon.pop();
    }
    
    // add new Head
    let newHead = {
        x : pokemonX,
        y : pokemonY
    }
    
    // game over
    if(pokemonX < box || pokemonX > 17 * box || pokemonY < 3*box || pokemonY > 17*box || collision(newHead,pokemon)){
        clearInterval(game);
    }
    
    if(pokemon.length==0){
      pokemon.unshift(newHead);
    }
    
    ctx.fillStyle = "red";
    ctx.font = "40px Changa one";
    ctx.fillText(score,2*box+5,1.5*box);
}

// call draw function every 200 ms
let game = setInterval(draw,200);